### Hi there 👋

<!--
**pllebres/pllebres** is a ✨ _special_ ✨ repository because its `README.md` (this file) appears on your GitHub profile.

Here are some ideas to get you started:

- Login UOC
- Pilar Llebres Ferriol
- En esta PEC, Hemos creado una cuenta en github, hemos instalado visual studio  y Node.js para poder trabajar el código en directamente en el navegador. Para saber cómo hacerlo he leido la documentación de la PEC y visualizado un video de Orielly, dónde me he autentificado como estudiantes de la UOC. Depúes a través de la terminal he configurado mi usuario y email de git. He comprobado que funcionaba con el comando git ini, Posteriormente, desde el navegador en github he creado un nuevo repositorio dónde he creado este README.md que ahora estoy editando con lo que se me pide en la tarea. Las dificultades no han sido grandes. He conseguido resolverlo en unos 50 minutos.  
-->
